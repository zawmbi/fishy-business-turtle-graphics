""""
Linda Mansour
Fishy Business
"""

import turtle
import random

s = turtle.getscreen()
t = turtle.Turtle()
t.shape('arrow')
t.speed(10)
t.hideturtle()
s.bgcolor("light blue")
color_list = ['red', 'blue', 'magenta', 'yellow', 'orange', 'brown', 'green', 'light green', 'purple', 'pink', 'maroon', 'cyan', 'gold','skyblue','turquoise', 'dark blue', 'navy']
fish_color = random.choice(color_list)

#This code is for the fish tank. 
def fish_tank(t, x, y, color):
  t.penup()
  t.goto(x,y)
  t.pencolor('black')
  t.fillcolor(color)
  t.begin_fill()
  t.pendown()
  t.forward(700)
  t.left(90)
  t.forward(375)
  t.left(90)
  t.forward(700)
  t.left(90)
  t.forward(375)
  t.end_fill()

  turtle.addshape('coralreef.gif')
  reef = turtle.Turtle()
  reef.penup()
  reef.shape('coralreef.gif')
  reef.goto(0, -80)

  turtle.addshape('blob.gif')
  blob = turtle.Turtle()
  blob.penup()
  blob.shape('blob.gif')
  blob.goto(-80, -180)
def fish1(t, sz, x, y, color):
    t.penup()
    t.goto(x,y)
    t.pencolor(color)
    t.fillcolor(color)
    t.begin_fill()
    t.pendown()
    t.forward(sz)
    t.left(120)
    t.forward(sz)
    t.left(120)
    t.forward(sz)
    t.left(120)
    t.goto(x + 10, y-5)
    t.circle(sz)
    t.end_fill()
    t.penup()

def bubbles(t, sz, x, y, color):
  t.penup()
  t.goto(x,y)
  t.pencolor('white')
  t.pendown()
  t.circle(sz)
  t.penup()
  t.goto(x-30,y-20)
  t.pendown()
  t.circle(sz+2)
  t.penup()
  t.goto(x + 25, y-40)
  t.pendown()
  t.penup()
  t.goto(x-50, y+40)
  t.pendown()
  t.circle(sz-2)
   
def shark_swim (t, start, end):
  shark.goto(start[0], start[1])
  shark.speed(1)
  shark.goto(end[0],end[1])


fish_tank(t,-350,-200,"#0AA3CF")

#calling the bubbles
for i in range(15):
  x =  random.randint(-300,300)
  y = random.randint(-200,150)
  sz = random.randint(2,5)
  bubbles(t, sz, x, y, 'light blue')
#calling the 15 fish
for i in range(15):
  x =  random.randint(-200,200)
  y = random.randint(-100,100)
  sz = random.randint(5,30)
  fish_color = random.choice(color_list)
  fish1(t, sz, x, y, fish_color)


#Adding the shark and his line.
turtle.addshape('shark.gif')
shark = turtle.Turtle()
shark.penup()
shark.shape('shark.gif')
shark.goto(-200, -120)
shark.speed(1)

choice = input("Would you like to chase the rainbow fish? Yes or No: \n")
if choice == 'Yes':
  
  t.pencolor('dark blue')
  style = ('Comic sans', 15)
  t.goto(-350, 175)
  t.write('Bruce the Shark: "I am going to eat some rainbow fish tonight!!"', font=style)
  
  #Adding the rainbow fish
  turtle.addshape('rainbowfish.gif')
  rainbow_fish = turtle.Turtle()
  rainbow_fish.penup()
  rainbow_fish.shape('rainbowfish.gif')
  rainbow_fish.goto(300,120)
  
  #The function for the fish swimming away from the shark.
  def fish_run(t, start, end):
    style = ('Comic sans', 13)
    t.pencolor('black')
    rainbow_fish.goto(start[0],start[1])
    t.goto(150, 80)
    t.write("The chase is on!", font =style)
    rainbow_fish.speed(1)
    rainbow_fish.goto(end[0],end[1])
  
  
  
  start = [300,100]
  end = [-300,100]
  
  j = 2
  for j in range(1): 
    fish_run(t, start, end)
    shark_swim(t, start, end)
    t.penup()
    t.goto(-200,100)
    t.pencolor('dark blue')
    t.write('Gotcha!')
else:
  print("Alright! No dinner then.")